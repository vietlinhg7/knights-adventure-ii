Thank you for purchasing one of my game assets!

You can find the full collection on itch.io:
https://harbingersh.itch.io/

License: You may use this asset pack in both free and commercial projects.
You can modify it after your own needs. You may not redistribute it or resell it.

If you need any help figuring things out, have any questions, or just want to see what I'm up to, please visit my Twitter!
https://twitter.com/_HarbingerSh