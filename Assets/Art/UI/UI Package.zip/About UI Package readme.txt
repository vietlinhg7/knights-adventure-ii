Hi, thanks for choosing the UI Package!

------------------------------------------------

Please note: this is not a quick and easy plug-and-play RPG Maker-type asset.

You'll need to build interfaces from different parts.
Building your own interface style is completely possible using the elements however you like!.
You can modify it after your own needs to suit you style.

------------------------------------------------

This asset is meant to have everything you need to make a GUI for a Minecraft or Terraria or Stardew Valley style game.
Seek the Tutorial folder for pre-build designs to help you get started.

------------------------------------------------

I'll add more to this file as necessary.
Please let me know if you have any issues, or notice any errors.

Thanks!
HarbingerSh
